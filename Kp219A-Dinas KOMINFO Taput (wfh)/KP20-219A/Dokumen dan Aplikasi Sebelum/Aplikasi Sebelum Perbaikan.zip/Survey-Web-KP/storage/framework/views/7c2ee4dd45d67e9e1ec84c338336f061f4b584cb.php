
<?php $__env->startSection('content'); ?>

<?php if(session('sukses')): ?>
<div class="alert alert-success" role="alert">
  <?php echo e(session('sukses')); ?>

</div>
<?php endif; ?>
     <h2>Layanan <?php echo e($instansi['nama_instansi']); ?> Kabupaten Tapanuli Utara</h2>
     <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
       Tambah Layanan
     </button>


     <table class="table table-striped">
        <thead class="thead-dark">
          <th>No</th>
          <th>Nama Layanan</th>
          <th>Keterangan</th>
          <th>Action</th>
        </thead>
        <tbody>
          <tr>
            <?php $no = 1; ?>
            <?php $__currentLoopData = $layanans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $layanan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <td><?= $no++; ?></td>
            <td><?php echo e($layanan['nama_layanan']); ?></td>
            <td><?php echo e($layanan['keterangan_layanan']); ?></td>
            <td> <a href="/instansi/layanan/<?php echo e($layanan['id']); ?>/edit_layanan" class="btn btn-warning">Edit</a> </td>
            <td> <a href="/instansi/layanan/<?php echo e($layanan['id']); ?>/delete_layanan" class="btn btn-danger">Delete</a> </td>
          </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
     </table>
     <!-- Modal -->
     <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
       <div class="modal-dialog">
         <div class="modal-content">
           <div class="modal-header">
             <h5 class="modal-title" id="exampleModalLabel">Tambah Layanan</h5>
             <button type="button" class="close" data-dismiss="modal" aria-label="Close">
               <span aria-hidden="true">&times;</span>
             </button>
           </div>
           <div class="modal-body">
             <form action="/instansi/layanan/<?php echo e($instansi['id']); ?>/store_layanan" method="POST">
               <?php echo e(csrf_field()); ?>

               <div class="form-group">
                 <label for="namaLayanan">Nama Layanan</label>
                 <input name="nama_layanan" type="text" class="form-control" id="namaLayanan" required>
               </div>

               <div class="form-group">
                 <label for="keteranganLayanan">Keterangan Layanan</label>
                 <textarea name="keterangan_layanan" type="text" class="form-control" id="keteranganLayanan" required></textarea>
               </div>

               <div class="modal-footer">
                 <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                 <button type="submit" class="btn btn-primary">Tambah</button>
               </div>
             </form>
           </div>
         </div>
       </div>
     </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Survey-Web-KP\resources\views/admin/layanan/show.blade.php ENDPATH**/ ?>