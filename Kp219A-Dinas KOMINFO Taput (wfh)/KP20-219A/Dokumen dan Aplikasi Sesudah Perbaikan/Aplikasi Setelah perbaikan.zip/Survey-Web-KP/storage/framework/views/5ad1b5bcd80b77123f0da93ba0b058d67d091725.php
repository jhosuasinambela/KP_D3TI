
<?php $__env->startSection('contentUser'); ?>
  <h1>Daftar Survey.</h1>

  <ol>
    <?php for($i=1; $i <= 3; $i++): ?>
    <li>
      <a href="<?php echo e(url('/pertanyaanSurveyUser')); ?>"><?php echo e('Survey '.$i); ?></a>
    </li>
    <?php endfor; ?>
  </ol>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.masterUser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Survey-Web-KP\resources\views/daftarSurveyLayananUser.blade.php ENDPATH**/ ?>