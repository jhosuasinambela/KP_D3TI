
<?php $__env->startSection('content'); ?>
<h1>Hasil Survey Kepuasan Masyarakat</h1>
<a href="/questionnaires/create" class="btn btn-dark">Create New Questionnaire</a>


<div class="panel">
  <div class="panel-heading">My Questionnaire</div>
  <div class="panel-body">
    <ul class="list-group">
        <?php $__currentLoopData = $questionnaires; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $questionnaire): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li class="list-group-item">
            <a href="<?php echo e($questionnaire->path()); ?>"><?php echo e($questionnaire->title); ?></a>
            <div class="mt-2">
              <small>Tujuan : <?php echo e($questionnaire->purpose); ?></small>
            </div>
            <div class="mt-2">
              <small> <b>Share Url</b> </small>
              <p>
                <a href="<?php echo e($questionnaire->publicPath()); ?>"><?php echo e($questionnaire->publicPath()); ?></a>
              </p>
            </div>

          </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
</div>


<!-- <table class="table table-dark">
  <thead>
    <th>Nama Instansi</th>
    <th>Jumlah Responden</th>
    <th>Action</th>
  </thead>
  <tbody>
    <?php for($i = 0; $i < 5; $i++): ?>
    <tr>
      <td>Kominfo</td>
      <td>80</td>
      <td> <a href="<?php echo e(url('/chart')); ?>">Lihat Grafik</a> </td>
    </tr>
    <?php endfor; ?>
  </tbody>
</table> -->


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Survey-Web-KP\resources\views/admin/hasilSurvey.blade.php ENDPATH**/ ?>