
<?php $__env->startSection('content'); ?>
<button class="btn" ><a class="btn btn-primary btn-md" href="<?php echo e(url('/buatSurvey')); ?>" >Buat Survey</a></button>
<table class="table table-dark">
  <thead>
    <th>Nama Instansi</th>
    <th>Nama Kepala Dinas</th>
    <th>Action</th>
  </thead>
  <tbody>
    <tr>
      <td scope="row">DISKOMINFO</td>
      <td>Polmudi Sagala</td>
      <td><a href="#">Hapus Survey</a></td>
    </tr>
    <tr>
      <td scope="row">Dinas Pariwisata</td>
      <td>Binhot Isak Aritonang</td>
      <td><a href="#">Hapus Survey</a></td>
    </tr>
    <tr>
      <td scope="row">Dinas Usaha Kecil dan Menengah</td>
      <td>Marco Taruli Parlindungan Panggabean</td>
      <td><a href="#">Hapus Survey</a></td>
    </tr>
    <tr>
      <td scope="row">Dinas Pertanian</td>
      <td>Sondang Erikson Yosua Pasaribu</td>
      <td><a href="#">Hapus Survey</a></td>

    </tr>
  </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Survey-Web-KP\resources\views/survey.blade.php ENDPATH**/ ?>