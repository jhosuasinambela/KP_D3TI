
<?php $__env->startSection('content'); ?>

<div class="container-fluid">
  <?php if(session('sukses')): ?>
  <div class="alert alert-success" role="alert">
    <?php echo e(session('sukses')); ?>

  </div>
  <?php endif; ?>

  <div class="row">
    <div class="col-md-12">
      <h1><?php echo e($questionnaire->title); ?></h1>
      <a class="btn btn-primary" href="/questionnaires/<?php echo e($questionnaire->id); ?>/questions/create">Buat Pertanyaan</a>
      <a class="btn btn-primary" href="/surveys/<?php echo e($questionnaire->id); ?>-<?php echo e(Str::slug($questionnaire->title)); ?>">Lakukan Survey</a>
      <a class="btn btn-primary" href="/questionnaires/<?php echo e($questionnaire->id); ?>/export">Export Excel</a>
      <a class="btn btn-primary" href="/questionnaires/<?php echo e($questionnaire->id); ?>/exportPDF">Export PDF</a>
    </div>
  </div>

      <?php $no=1; ?>
    <?php $__currentLoopData = $questionnaire->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if($no % 2 == 0): ?>
          <div class="col-md-6">
            <!-- PANEL SCROLLING -->
            <div id="panel-scrolling-demo" class="panel">
              <div class="panel-heading">
                <h3 class="panel-title"><?php echo e($no++); ?>.<?php echo e($question->question); ?></h3>
              </div>
                  <div class="panel-body" style="overflow: hidden; width: auto; height: 275px;">
                    <ul class="list-group">
                      <?php $__currentLoopData = $question->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item d-flex justify-content-betweeen">
                          <div class=""><?php echo e($answer->answer); ?></div>

                          <?php if($question->responses->count()): ?>
                          <div class=""><?php echo e(intval($answer->responses->count() * 100 / $question->responses->count())); ?>%</div>
                          <?php endif; ?>
                          <div class="">
                            <?php if($answer->responses()->count() == 0): ?>
                            <small class="text-success">Belum ada respon.</small>
                            <?php else: ?>
                            <?php echo e($answer->responses()->count()); ?> orang
                            <?php endif; ?>
                          </div>
                        </li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <div class=""><?php echo e($question->responses->count()); ?> orang</div> <!-- Jumlah Orang yang melakukkan Survey -->
                    </ul>
                  </div>
              <div class="panel-footer">
                <form action="/questionnaires/<?php echo e($questionnaire->id); ?>/questions/<?php echo e($question->id); ?>" method="post">
                  <?php echo method_field('DELETE'); ?>
                  <?php echo csrf_field(); ?>

                  <button type="submit" class="btn btn-sm btn-danger col-md-5">Hapus Pertanyaan</button>
                </form>
                  <a href="/questionnaires/<?php echo e($questionnaire->id); ?>/questions/<?php echo e($question->id); ?>/edit" class="btn btn-sm btn-warning col-md-5">Edit Pertanyaan</a>
              </div>
           </div>
            <!-- END PANEL SCROLLING -->
        </div>
      <?php elseif($no % 2 == 1): ?>
      <div class="col-md-6">
				<!-- PANEL NO CONTROLS -->
				<div id="panel-scrolling-demo" class="panel">
					<div class="panel-heading">
						<h3 class="panel-title"><?php echo e($no++); ?>.<?php echo e($question->question); ?></h3>
					</div>

					<div class="panel-body" style="overflow: hidden; width: auto; height: 275px;">
            <?php $__currentLoopData = $question->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="list-group-item d-flex justify-content-betweeen">
              <div class=""><?php echo e($answer->answer); ?></div>
                <?php if($question->responses->count()): ?>
              <div class=""><?php echo e(intval($answer->responses->count() * 100 / $question->responses->count())); ?>%</div>
                <?php endif; ?>
                <div class="">
                  <?php if($answer->responses()->count() == 0): ?>
                  <small class="text-success">Belum ada respon.</small>
                  <?php else: ?>
                  <?php echo e($answer->responses()->count()); ?> orang
                  <?php endif; ?>
                </div>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!-- <div class=""><?php echo e($question->responses->count()); ?> orang</div>  Jumlah Orang yang melakukkan Survey -->
					</div>

          <div class="panel-footer">
            <form action="/questionnaires/<?php echo e($questionnaire->id); ?>/questions/<?php echo e($question->id); ?>" method="post">
              <?php echo method_field('DELETE'); ?>
              <?php echo csrf_field(); ?>

              <button type="submit" class="btn btn-sm btn-danger col-md-5">Hapus Pertanyaan</button>
            </form>
              <a href="/questionnaires/<?php echo e($questionnaire->id); ?>/questions/<?php echo e($question->id); ?>/edit" class="btn btn-sm btn-warning col-md-5">Edit Pertanyaan</a>
          </div>
				</div>
				<!-- END PANEL NO CONTROLS -->
		</div>
      <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-12">
      <div id="chartSurvey"></div>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('footer'); ?>
  <script src="https://code.highcharts.com/highcharts.js"></script>


  <script type="text/javascript">
    Highcharts.chart('chartSurvey', {
    chart: {
        type: 'column'
    },
    title: {
        text: 'Laporan Hasil Survey'
    },
    xAxis: {
        categories: <?php echo json_encode($pertanyaan); ?>,
        crosshair: true
    },
    yAxis: {
        min: 0,
        title: {
            text: 'Persentase Respon'
        }
    },
    tooltip: {
        headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
        pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
            '<td style="padding:0"><b>{point.y:.1f} orang</b></td></tr>',
        footerFormat: '</table>',
        shared: true,
        useHTML: true
    },
    plotOptions: {
        column: {
            pointPadding: 0.2,
            borderWidth: 0
        }
    },
    series: [{
        name: 'Jumlah Responden',
        data: <?php echo json_encode($responden); ?>


    }]
  });
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Survey-Web-KP\resources\views/admin/questionnaire/show.blade.php ENDPATH**/ ?>