
<?php $__env->startSection('content'); ?>
  <h2> <b>Standar Kepuasan Masyarakat(SKM)</b> </h2>
  <h1>Silahkan Pilih Instansi untuk melakukan Survey.</h1>

  <form>
    <p class="p">Pilih Instansi
      <select class="form-control" name='instansi'>
        <option value='Instansi A'>Instansi A</option>
        <option value='Instansi A'>Instansi B</option>
        <option value='Instansi A'>Instansi C</option>
        <option value='Instansi A'>Instansi D</option>
        <option value='Instansi A'>Instansi E</option>
      </select>
    </p>
    <!-- <input type='submit' name='tombol' value='next'/> -->
    <button class="btn btn-default" type="button" name="button"><a href="<?php echo e(url('/daftarLayananUser')); ?>">Next</a> </button>
  </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Survey-Web-KP\resources\views/users/homeUser.blade.php ENDPATH**/ ?>