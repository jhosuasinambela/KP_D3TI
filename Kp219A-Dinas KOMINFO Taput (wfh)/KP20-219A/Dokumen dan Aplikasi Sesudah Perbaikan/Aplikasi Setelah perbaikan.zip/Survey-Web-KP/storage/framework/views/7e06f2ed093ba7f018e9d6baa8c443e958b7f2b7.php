
<?php $__env->startSection('content'); ?>
<h1>Edit layanan</h1>

<form action="/instansi/layanan/<?php echo e($layanan['id']); ?>/update_layanan" method="POST">
  <?php echo e(csrf_field()); ?>

  <div class="form-group hidden">
    <label for="namaLayanan">Nama Layanan</label>
    <input name="instansi_id" type="text" class="form-control" id="namaLayanan" value="<?php echo e($layanan['instansi_id']); ?>" required>
  </div>

  <div class="form-group">
    <label for="namaLayanan">Nama Layanan</label>
    <input name="nama_layanan" type="text" class="form-control" id="namaLayanan" value="<?php echo e($layanan['nama_layanan']); ?>" required>
  </div>

  <div class="form-group">
    <label for="keteranganLayanan">Keterangan Layanan</label>
    <textarea name="keterangan_layanan" type="text" class="form-control" id="keteranganLayanan" value="" required><?php echo e($layanan['keterangan_layanan']); ?></textarea>
  </div>

  <div class="modal-footer">
    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
    <button type="submit" class="btn btn-primary">Edit</button>
  </div>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Survey-Web-KP\resources\views/admin/layanan/edit_layanan.blade.php ENDPATH**/ ?>