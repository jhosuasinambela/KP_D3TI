
<?php $__env->startSection('content'); ?>
  <h1>Kuesioner Baru</h1>
    <form class="" action="/questionnaires" method="post">
      <?php echo csrf_field(); ?>

      <div class="form-group">
        <label for="title">Judul</label>
        <input name="title" type="text" value="<?php echo e(old('title')); ?>" id="title" class="form-control" placeholder="Masukkan Judul">
        <small id="titleHelp" class="form-text text-muted">Buat judul Kuesioner yang menarik.</small>

        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <small class="text-danger"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>


      <div class="form-group">
        <label for="instansi">Pilih Instansi:</label>
        <select name="instansi_id" class="form-control instansiCategory" id="instansiCatId">
          <option value="0" disabled="true" selected="true">-Pilih-</option>
            <?php $__currentLoopData = $instansi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ins): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($ins->id); ?>"><?php echo e($ins->nama_instansi); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['instansi_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <small class="text-danger"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <div class="form-group">
          <label>Nama Layanan : </label>
          <select name="layanan_id" class="form-control namaLayanan">
            <option value="0" selected="true" disabled="true">-Nama Layanan-</option>
          </select>

          <?php $__errorArgs = ['layanan_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <small class="text-danger"><?php echo e($message); ?></small>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>


        <script type="text/javascript">
          $(document).ready(function(){
            $(document).on("change",".instansiCategory",function(){

              let instansiId = $(this).val();
              let div = $(this).parent();
              let op =" ";

              $.ajax({
                type: "GET",
                url: '<?php echo URL::to('findLayananName'); ?>',
                data: {'id':instansiId},
                success: function(data){
                  // console.log('suscces');
                  // console.log(data);
                  // console.log(data.length);
                  // console.log(data[0]['nama_layanan']);

                  op += '<option value="0" selected disabled>-Pilih Layanan</option>';

                  for (var i = 0; i<data.length; i++) {
                    op += '<option value="'+data[i].id+'">'+data[i].nama_layanan+'</option>';
                  }

                  div.find(".namaLayanan").html(" ");
                  div.find(".namaLayanan").append(op);
                },
                error: function(){

                }
              });
            });
          });
        </script>
      </div>

      <div class="form-group">
        <label for="date">Tanggal Berakhir</label>
        <input name="due_date" value="<?php echo e(old('due_date')); ?>" type="date" class="form-control">
        <small id="dateHelp" class="form-text-muted">Tanggal Berakhir Kuesioner.</small>

        <?php $__errorArgs = ['due_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <small class="text-danger"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>


      <div class="form-group">
        <label for="purpose">Tujuan</label>
        <input name="purpose" type="text" value="<?php echo e(old('purpose')); ?>" id="purpose" class="form-control" placeholder="Masukkan Tujuan">
        <small id="purposeHelp" class="form-text text-muted">Buat Tujuan Kuesioner yang akan meningkatkan respon.</small>

        <?php $__errorArgs = ['purpose'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <small class="text-danger"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      <button type="submit" class="btn btn-primary">Buat Kuesioner</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Survey-Web-KP\resources\views/admin/questionnaire/create.blade.php ENDPATH**/ ?>