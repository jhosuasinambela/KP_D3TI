
<?php $__env->startSection('content'); ?>
     <h2>Layanan Instansi Kabupaten Tapanuli Utara</h2>

     <table class="table table-striped">
        <thead class="thead-dark">
        <tr>
            <th scope="col">Nama Layanan</th>
            <th scope="col">Aksi</th>
          </tr>
        </thead>

        <tbody>
            <tr>
                <td>Layanan A</td>
                <td><a href="/ubahlayanan">Ubah</a></td>
            </tr>

            <tr>
                <td>Layanan B</td>
                <td><a href="/ubahlayanan">Ubah</a></td>
            </tr>
        </tbody>
     </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Survey-Web-KP\resources\views/layanan.blade.php ENDPATH**/ ?>