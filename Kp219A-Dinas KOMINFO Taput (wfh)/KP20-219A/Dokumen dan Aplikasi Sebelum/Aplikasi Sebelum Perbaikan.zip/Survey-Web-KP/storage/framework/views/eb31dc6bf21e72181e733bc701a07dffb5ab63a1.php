
<?php $__env->startSection('content'); ?>

<table class="table">
  <form action="/instansi/<?php echo e($instansi['id']); ?>/update_instansi" method="POST">
      <?php echo e(csrf_field()); ?>

  <tr>
    <td>
      <div class="form-group">
        <label for="namaInstansi">Nama Instansi</label>
        <input name="nama_instansi" type="text" class="form-control" id="namaInstansi" value="<?php echo e($instansi['nama_instansi']); ?>" required>
      </div>
    </td>
  </tr>
  <tr>
    <td>
      <div class="form-group">
        <label for="namaPimpinan">Nama Pimpinan</label>
        <input name="nama_pimpinan" type="text" class="form-control" id="namaPimpinan" value="<?php echo e($instansi['nama_pimpinan']); ?>" required>
      </div>
    </td>
  </tr>
  <tr>
    <td>
      <div class="form-group">
        <label for="alamat">Alamat</label>
        <textarea name="alamat" name="name" rows="8" cols="80" class="form-control" required><?php echo e($instansi['alamat']); ?></textarea>
      </div>
    </td>
  </tr>
  <tr>
    <td>
      <div class="form-group">
        <label for="keterangan">Keterangan Instansi</label>
        <textarea name="keterangan" rows="8" cols="80" class="form-control" required><?php echo e($instansi['keterangan']); ?></textarea>
      </div>
    </td>
  </tr>
  <tr>
    <td>
      <div class="modal-footer">
        <button type="submit" class="btn btn-primary">Edit Instansi</button>
      </div>

    </td>
  </tr>
    </form>
</table>











<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Survey-Web-KP\resources\views/admin/instansi/editInstansi.blade.php ENDPATH**/ ?>