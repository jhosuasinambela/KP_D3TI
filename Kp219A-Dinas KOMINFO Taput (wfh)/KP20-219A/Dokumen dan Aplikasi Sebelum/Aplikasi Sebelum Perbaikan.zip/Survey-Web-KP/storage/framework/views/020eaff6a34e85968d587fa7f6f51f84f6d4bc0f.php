
<?php $__env->startSection('content'); ?>
  <h1>Buat Pertanyaan.</h1>
    <form class="" action="/questionnaires/<?php echo e($questionnaire->id); ?>/questions" method="post">
      <?php echo csrf_field(); ?>
      <div class="form-group">
        <label for="question">Judul</label>
        <input name="question[question]" type="text" value="<?php echo e(old('question.question')); ?>" id="question" class="form-control" placeholder="Masukkan Pertanyaan">
        <small id="questionHelp" class="form-text text-muted">Buat Pertanyaan singkat dan Jelas.</small>

        <?php $__errorArgs = ['question.question'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <small class="text-danger"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>

      <div class="form-group">
        <fieldset>
          <legend>Pilihan</legend>
          <small id="choisesHelp" class="form-text text-muted">Berikan Pilihan Jawaban yang anda inginkan.</small>

            <div>
              <div class="form-group">
                <label for="answer1">Pilihan 1</label>
                <input name="answers[][answer]" value="<?php echo e(old('answers.0.answer')); ?>" id="answer1" type="text" class="form-control" placeholder="Masukkan Pilihan 1" aria-describedby="choisesHelp">

                <?php $__errorArgs = ['answers.0.answer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>

            <div>
              <div class="form-group">
                <label for="answer2">Pilihan 2</label>
                <input name="answers[][answer]" value="<?php echo e(old('answers.1.answer')); ?>" id="answer2" type="text" class="form-control" placeholder="Masukkan Pilihan 2" aria-describedby="choisesHelp">

                <?php $__errorArgs = ['answers.1.answer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>

            <div>
              <div class="form-group">
                <label for="answer3">Pilihan 3</label>
                <input name="answers[][answer]" value="<?php echo e(old('answers.2.answer')); ?>" id="answer3" type="text" class="form-control" placeholder="Masukkan Pilihan 3" aria-describedby="choisesHelp">

                <?php $__errorArgs = ['answers.2.answer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>

            <div>
              <div class="form-group">
                <label for="answer4">Pilihan 4</label>
                <input name="answers[][answer]" value="<?php echo e(old('answers.3.answer')); ?>" id="answer4" type="text" class="form-control" placeholder="Masukkan Pilihan 4" aria-describedby="choisesHelp">

                <?php $__errorArgs = ['answers.3.answer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
        </fieldset>
      </div>

      <button type="submit" class="btn btn-primary">Tambah Pertanyaan</button>
    </form>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Survey-Web-KP\resources\views/admin/question/create.blade.php ENDPATH**/ ?>