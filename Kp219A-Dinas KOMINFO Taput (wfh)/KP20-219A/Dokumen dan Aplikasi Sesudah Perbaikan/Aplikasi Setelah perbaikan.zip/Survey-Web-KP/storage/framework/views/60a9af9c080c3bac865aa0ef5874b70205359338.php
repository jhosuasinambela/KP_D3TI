
<?php $__env->startSection('content'); ?>
  <h1>Comming Soon</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Survey-Web-KP\resources\views/chart.blade.php ENDPATH**/ ?>