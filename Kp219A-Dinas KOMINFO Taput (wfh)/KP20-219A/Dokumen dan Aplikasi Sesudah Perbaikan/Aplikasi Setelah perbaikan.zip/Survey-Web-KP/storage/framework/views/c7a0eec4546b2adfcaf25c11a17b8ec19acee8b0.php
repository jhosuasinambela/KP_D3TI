
<?php $__env->startSection('contentUser'); ?>
  <h1>Terimakasih Telah Menjawab Survey.Tanggapan Anda Telah Kami Simpan.</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.masterUser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Survey-Web-KP\resources\views/afterSurveyUser.blade.php ENDPATH**/ ?>