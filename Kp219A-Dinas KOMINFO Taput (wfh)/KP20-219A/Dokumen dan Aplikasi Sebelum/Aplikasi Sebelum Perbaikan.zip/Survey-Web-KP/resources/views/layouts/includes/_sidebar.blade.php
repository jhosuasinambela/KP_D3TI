<div id="sidebar-nav" class="sidebar">
  <div class="sidebar-scroll">
    <nav>
      <ul class="nav">

        <li><a href="{{ url('/hasilSurvey') }}" class=""><i class="lnr lnr-chart-bars"></i> <span>Hasil Survey</span></a></li>
        <li><a href="{{ url('/instansi') }}" class=""><i class="lnr lnr-home"></i> <span>Instansi</span></a></li>
        <li><a href="{{ url('/') }}" class=""><i class="lnr lnr-chart-bars"></i> <span>Survey</span></a></li>

      </ul>
    </nav>
  </div>
</div>
