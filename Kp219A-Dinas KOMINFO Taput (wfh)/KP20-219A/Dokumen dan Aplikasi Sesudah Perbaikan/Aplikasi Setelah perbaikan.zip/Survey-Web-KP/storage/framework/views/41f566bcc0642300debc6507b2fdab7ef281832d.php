
<?php $__env->startSection('contentUser'); ?>
  <h1>Daftar Layanan.</h1>

  <ol>
    <?php for($i=1; $i <= 3; $i++): ?>
    <li>
      <a href="/daftarSurveyLayananUser"><?php echo e('Layanan '.$i); ?></a>
    </li>
    <?php endfor; ?>
  </ol>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.masterUser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Survey-Web-KP\resources\views/daftarLayananUser.blade.php ENDPATH**/ ?>