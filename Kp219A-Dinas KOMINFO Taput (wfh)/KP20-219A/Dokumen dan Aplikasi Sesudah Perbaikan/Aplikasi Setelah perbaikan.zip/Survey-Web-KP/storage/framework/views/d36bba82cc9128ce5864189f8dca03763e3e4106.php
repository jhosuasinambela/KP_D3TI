
<?php $__env->startSection('content'); ?>
            <h1>Hasil Survey Kepuasan Masyarakat</h1>
            <table class="table table-dark">
              <thead>
                <th>Nama Instansi</th>
                <th>Jumlah Responden</th>
                <th>Action</th>
              </thead>
              <tbody>
                <?php for($i = 0; $i < 5; $i++): ?>
                <tr>
                  <td>Kominfo</td>
                  <td>80</td>
                  <td> <a href="<?php echo e(url('/chart')); ?>">Lihat Grafik</a> </td>
                </tr>
                <?php endfor; ?>
              </tbody>
            </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Survey-Web-KP\resources\views/hasilSurvey.blade.php ENDPATH**/ ?>