
<?php $__env->startSection('content'); ?>
<h1>Daftar Survey Kepuasan Masyarakat</h1>
<a href="/questionnaires/create" class="btn btn-dark">Buat Kuesioner Baru</a>
<br><br>
<?php if(session('sukses')): ?>
  <div class="alert alert-success" role="alert">
    <?php echo e(session('sukses')); ?>

  </div>
<?php endif; ?>





<div class="panel">
  <div class="panel-heading">Daftar Kuesioner</div>
  <div class="panel-body">
        <?php $__currentLoopData = $questionnaires; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $questionnaire): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <ul class="list-group">
          <li class="list-group-item">
            <a href="<?php echo e($questionnaire->path()); ?>"><?php echo e($questionnaire->title); ?></a>
            <div class="mt-2">
              <small>Instansi : <?php echo e($questionnaire->instansi->nama_instansi); ?></small>
            </div>
            <div class="mt-2">
              <small>Layanan : <?php echo e($questionnaire->layanan->nama_layanan); ?></small>
            </div>
            <div class="mt-2">
              <small>Tujuan : <?php echo e($questionnaire->purpose); ?></small>
            </div>
            <div class="mt-2">
              <small>Tanggal Berakhir : <b class="text-success"><?php echo e($questionnaire->due_date); ?></b></small>
            </div>

            <?php

            $tanggal1 = new DateTime($questionnaire->due_date);
            $tanggal2 = new DateTime();

            $perbedaan = $tanggal2->diff($tanggal1)->format("%a");


             ?>
            <small class="text-danger" style="position:absolute; background: #ddd;bottom:0; right:0;">Sisa <?php echo e($perbedaan); ?> Hari lagi</small>
            <div class="mt-2">
              <small> <b>Share Url</b> </small>
              <p>
                <a href="<?php echo e($questionnaire->publicPath()); ?>"><?php echo e($questionnaire->publicPath()); ?></a>
              </p>
            </div>
            <div class="col-md-2">
              <a href="/questionnaires/edit/<?php echo e($questionnaire->id); ?>" class="btn btn-warning">Edit</a>
            </div>

            <div class="form-group div-col-md-2">
              <form action="/questionnaires/<?php echo e($questionnaire->id); ?>" method="post">
                <?php echo method_field('DELETE'); ?>
                <?php echo csrf_field(); ?>

                <button type="submit" class="btn btn-md btn-danger">Hapus</button>
              </form>
            </div>
          </li>
        </ul>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Survey-Web-KP\resources\views/admin/listSurvey.blade.php ENDPATH**/ ?>